<p align="center">
  <img src="https://img.shields.io/badge/MarkDownIngress-LLM%20Security-blue?style=for-the-badge" alt="MarkDownIngress">
</p>

<h1 align="center">MarkDownIngress</h1>

<p align="center">
  <strong>Deterministic, Injection-Resistant Web → Markdown Engine for LLM Pipelines</strong>
</p>

<p align="center">
  <a href="https://pypi.org/project/markdown-ingress/"><img src="https://badge.fury.io/py/markdown-ingress.svg" alt="PyPI version"></a>
  <a href="https://www.python.org/downloads/"><img src="https://img.shields.io/badge/python-3.11+-blue.svg" alt="Python 3.11+"></a>
  <a href="LICENSE"><img src="https://img.shields.io/badge/License-MIT-yellow.svg" alt="License: MIT"></a>
  <a href="https://github.com/seifreed/MarkDownIngress/actions"><img src="https://github.com/seifreed/MarkDownIngress/workflows/CI/badge.svg" alt="Tests"></a>
  <img src="https://img.shields.io/badge/coverage-63%25-orange.svg" alt="Coverage">
</p>

<p align="center">
  <img src="https://img.shields.io/badge/tokens-78%25%20reduction-success?style=flat-square" alt="Token Reduction">
  <img src="https://img.shields.io/badge/security-injection%20detection-red?style=flat-square" alt="Security">
  <img src="https://img.shields.io/badge/mode-deterministic-purple?style=flat-square" alt="Deterministic">
</p>

---

## Overview

**MarkDownIngress** is a security-first web content ingestion engine designed specifically for LLM pipelines. It extracts, sanitizes, and analyzes web content while detecting prompt injection attempts, producing deterministic Markdown output optimized for token efficiency.

### What It Is **NOT**

| ❌ | Description |
|---|-------------|
| Web Crawler | Not designed for recursive site crawling |
| RAG Framework | Not a complete RAG solution |
| HTML Converter | Not a generic HTML→Markdown tool |

### What It **IS**

| ✅ | Description |
|---|-------------|
| **Ingestion Security Engine** | Detects and flags prompt injection attempts |
| **Token Optimizer** | Reduces token count by 70-80% on average |
| **Deterministic Processor** | Same input = same output, always |
| **LLM Pipeline Component** | Drop-in solution for safe content ingestion |

### Processing Pipeline

```
Untrusted Web URL
        ↓
🌐 HTTP Fetch (Fast Mode)
        ↓
📄 Content Extraction (Readability)
        ↓
🧹 Sanitization (Remove Scripts/Tracking)
        ↓
🔒 Security Analysis (Injection Detection)
        ↓
📝 Markdown Conversion
        ↓
✅ Safe, Deterministic Output
```

---

## Key Features

| Feature | Description |
|---------|-------------|
| **Fast Mode** | HTTP-only fetching (no JS execution) |
| **Render Mode** | Playwright-based rendering for SPAs |
| **Batch Processing** | Process multiple URLs concurrently (v0.3) |
| **Caching** | Memory & SQLite caching with TTL (v0.3) |
| **Policy Engine** | Configurable security policies (v0.3) |
| **Structural Hashing** | ✨ **NEW v0.4** Structure-aware fingerprinting |
| **Security Reports** | ✨ **NEW v0.4** Comprehensive JSON reports |
| **Config Files** | ✨ **NEW v0.4** YAML/JSON configuration support |
| **CLI Batch Command** | ✨ **NEW v0.4** `markdown-ingress batch urls.txt` |
| **Plugin System** | ✨ **NEW v0.4** Custom injection pattern plugins |
| **Benchmarking** | ✨ **NEW v0.4** Performance metrics suite |
| **Security Analysis** | Pattern-based prompt injection detection |
| **Token Estimation** | Accurate token counts via tiktoken |
| **Content Hashing** | SHA256 for deduplication/versioning |
| **Hidden Content Detection** | Finds `display:none`, `hidden`, `aria-hidden` |
| **URL Sanitization** | Removes tracking params (utm_*, fbclid, etc.) |
| **Library + CLI** | Use as Python API or command-line tool |
| **Deterministic** | Reproducible output for caching |

### Supported Features

```
Extraction         Mozilla Readability algorithm
Cleaning           nav, footer, aside, script, style removal
Normalization      Unicode NFC, zero-width char removal
Security           10+ injection pattern detectors
Risk Scoring       0.0 (safe) → 1.0 (critical)
Token Models       GPT-4, Claude, GPT-3.5-turbo, etc.
Output Formats     Markdown, JSON, SafeDocument
Modes              Fast (HTTP), Render (Playwright) ✨ NEW
JavaScript         Fully rendered SPAs with Playwright ✨ NEW
```

---

## Installation

### From Source

```bash
git clone https://github.com/seifreed/MarkDownIngress.git
cd MarkDownIngress
python3 -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -e ".[dev]"
```

### With Render Mode (Playwright)

```bash
# Install base package plus render support
pip install -e ".[render]"

# Install browser for Playwright
playwright install chromium
```

### With Advanced Security (Nova)

```bash
# Install Nova-based advanced detection
pip install -e ".[security]"
```

### Quick Install (Core Only)

```bash
pip install -e .
```

---

## Quick Start

### Command Line Interface

```bash
# Single URL ingestion
markdown-ingress ingest https://example.com

# Single URL ingestion using a config file
markdown-ingress ingest https://example.com --config .markdowningress.yaml

# Batch processing (NEW in v0.4)
markdown-ingress batch urls.txt --output results/

# Render mode for JavaScript-heavy sites (v0.2)
markdown-ingress ingest https://spa-app.com --render

# Save markdown output
markdown-ingress ingest https://example.com --save output.md

# JSON output with metadata
markdown-ingress ingest https://example.com --json --save output.json

# Batch with JSON summary (v0.4)
markdown-ingress batch urls.txt --json --output summary.json

# Specify token model
markdown-ingress ingest https://example.com --model claude

# Permissive mode (lower security threshold)
markdown-ingress ingest https://example.com --permissive
```

### Example Output

```
============================================================
MarkDownIngress v0.7.0 - Ingestion Report
============================================================

📄 Title: Example Domain
🔗 URL: http://example.com

✔ Tokens: 33
  ↳ Saved: 119 tokens (78.29% reduction)

🔒 Injection Score: 0.000 (SAFE)

🔑 Hash: sha256:d6ac852cf2392c04d2cf3e3e4156f786cfbc4f46308ebe756ebd72cf9ffef4ef
⏱️  Fetch time: 116ms
```

---

## Usage

### Python Library

#### Basic Usage

```python
from markdown_ingress import ingest

# Ingest URL and get sanitized markdown
doc = ingest("https://example.com", mode="fast", strict=True)

print(doc.markdown)              # Clean markdown content
print(doc.token_estimate)        # Token count
print(doc.injection_score)       # 0.0-1.0 risk score
print(doc.content_hash)          # SHA256 hash
print(doc.flags)                 # Security warnings
```

#### Advanced Usage

```python
from markdown_ingress import ingest
from markdown_ingress.core.scoring import Scorer

# Fast mode (HTTP only, no JavaScript)
doc_fast = ingest(
    url="https://blog.example.com/article",
    mode="fast",
    strict=True,
    model="gpt-4",
    timeout=30.0
)

# Render mode (with JavaScript execution) - NEW in v0.2
doc_render = ingest(
    url="https://react-app.com",
    mode="render",  # Uses Playwright
    strict=True,
    model="gpt-4",
    timeout=60.0  # Render mode needs more time
)

# Analyze security
scorer = Scorer()
risk_level = scorer.get_risk_level(doc_fast.injection_score)
recommendation = scorer.get_recommendation(doc_fast.injection_score)

print(f"Risk Level: {risk_level}")
print(f"Recommendation: {recommendation}")

# Access metadata
print(f"Title: {doc_fast.metadata['title']}")
print(f"Mode: {doc_fast.metadata['mode']}")  # 'fast' or 'render'
print(f"Fetch time: {doc_fast.metadata['fetch_time_ms']}ms")
print(f"Token savings: {doc_fast.metadata['token_savings']}")
```

#### Batch Processing

```python
from markdown_ingress import ingest

urls = [
    "https://example.com/article1",
    "https://example.com/article2",
    "https://example.com/article3",
]

safe_docs = []
for url in urls:
    doc = ingest(url)
    if doc.injection_score < 0.3:  # Safe threshold
        safe_docs.append(doc)
        print(f"✓ {url}: {doc.token_estimate} tokens")
    else:
        print(f"⚠ {url}: High risk ({doc.injection_score})")

print(f"\nSafe documents: {len(safe_docs)}/{len(urls)}")
```

### v0.4 Features

#### Configuration Files

```python
from markdown_ingress import ingest
from markdown_ingress.core.config import load_config

# Auto-discover config from default locations
config = load_config()

# Or specify path explicitly  
config = load_config("my_config.yaml")

# Use config values with the public API
doc = ingest("https://example.com", config=config.to_ingest_config())

print(config.mode)                   # 'auto', 'fast' or 'render'
print(config.cache_enabled)          # True/False
print(config.batch_max_concurrent)   # 5
```

**YAML example (.markdowningress.yaml):**

```yaml
mode: fast
timeout: 45.0
strict: true
cache_enabled: true
cache_type: sqlite
batch_max_concurrent: 10
policy: normal
```

**Environment variable override:**

```bash
export MDI_MODE=render
export MDI_CACHE_ENABLED=true
export MDI_BATCH_MAX_CONCURRENT=20
```

#### Security Reports

```python
from markdown_ingress import generate_security_report

# Generate comprehensive security report
report = generate_security_report("https://suspicious-site.com")

# Export to JSON
report.save("security_report.json")

# Access detailed metrics
print(f"Injection score: {report.injection_score}")
print(f"Risk level: {report.risk_level}")
print(f"Token reduction: {report.token_reduction_percent}%")
print(f"Pattern matches: {report.pattern_matches}")
print(f"Structural hash: {report.structural_hash}")
```

#### Structural Hashing

```python
from markdown_ingress.core.hashing import Hasher

hasher = Hasher()

# Content hash (exact match required)
content_hash = hasher.hash_content(markdown)

# Structural hash (same structure = same hash, even if content differs)
structural_hash = hasher.hash_structural(markdown)

# Use case: Detect document structure changes
doc1 = "# Title\n## Section\nSome content"
doc2 = "# Title\n## Section\nDifferent content"

assert hasher.hash_structural(doc1) == hasher.hash_structural(doc2)
# True - same structure!
```

#### Plugin System

```python
from markdown_ingress.core.plugin import Plugin, PluginLoader

# Define custom plugin
class MySecurityPlugin(Plugin):
    def get_patterns(self):
        return [
            r'confidential information leak',
            r'internal use only',
            r'not for distribution'
        ]

# Load plugin
loader = PluginLoader()
loader.load_plugin(MySecurityPlugin())

# Get all patterns (default + custom)
all_patterns = loader.get_all_patterns()

# Or load from directory
loader.load_from_directory("./plugins")
```

#### Benchmarking

```python
from markdown_ingress.core.benchmark import Benchmark

bench = Benchmark(model="gpt-4")

# Single URL benchmark
result = bench.run_single("https://example.com", iterations=5)

print(f"Average time: {result.avg_time_ms:.1f}ms")
print(f"Token reduction: {result.reduction_percent:.1f}%")
print(f"Original: {result.original_tokens} tokens")
print(f"Cleaned: {result.cleaned_tokens} tokens")

# Batch benchmark
urls = ["https://example.com", "https://example.org"]
results = bench.run_batch(urls, iterations=3)

# Generate report
report = bench.generate_report(results)
print(report)
```


### Command Line Options

| Option | Description |
|--------|-------------|
| `url` | Target URL to ingest (positional) |
| `--config FILE` | Load YAML/JSON runtime config |
| `--render` | ✨ **NEW** Use render mode (Playwright for SPAs) |
| `--strict` | Enable strict security mode (default) |
| `--permissive` | Disable strict mode |
| `--model MODEL` | LLM model for token estimation (default: gpt-4) |
| `--timeout TIMEOUT` | Request timeout in seconds (default: 30) |
| `--json` | Output as JSON |
| `--save FILE` | Save output to file |
| `--version` | Show version |

---

## API Reference

### Main Function

```python
ingest(
    url: str,
    config: IngestConfig | Config | None = None,
    mode: Literal["fast", "render", "auto"] | None = None,
    strict: bool | None = None,
    model: str | None = None,
    timeout: float | None = None,
    ...
) -> SafeDocument
```

**Parameters:**

- `url` — Target URL to ingest
- `config` — Optional `IngestConfig` or file-based `Config`
- `mode` — Fetching mode override: `"fast"`, `"render"` or `"auto"`; defaults to `"auto"` when no config is provided
- `strict` — Optional strict security override
- `model` — Optional LLM model override (`gpt-4`, `claude`, `gpt-3.5-turbo`)
- `timeout` — Optional request timeout override in seconds

**Returns:** `SafeDocument` object

### SafeDocument Object

```python
@dataclass
class SafeDocument:
    markdown: str              # Cleaned markdown content
    metadata: dict             # URL, title, timing, token savings
    token_estimate: int        # Token count for specified model
    content_hash: str          # SHA256 hash (format: "sha256:...")
    injection_score: float     # 0.0 (safe) to 1.0 (critical)
    flags: list[str]           # Security warning flags
    removed_elements: dict     # Removed tags and hidden elements
```

---

## Examples

### LangChain Integration

```python
from langchain.document_loaders import BaseLoader
from langchain.schema import Document
from markdown_ingress import ingest

class MarkDownIngressLoader(BaseLoader):
    def __init__(self, url: str, strict: bool = True):
        self.url = url
        self.strict = strict
    
    def load(self) -> list[Document]:
        doc = ingest(self.url, strict=self.strict)
        
        return [Document(
            page_content=doc.markdown,
            metadata={
                "source": doc.metadata['url'],
                "title": doc.metadata['title'],
                "injection_score": doc.injection_score,
                "hash": doc.content_hash
            }
        )]

# Usage
loader = MarkDownIngressLoader("https://example.com/article")
docs = loader.load()
```

### FastAPI Endpoint

```python
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, HttpUrl
from markdown_ingress import ingest

app = FastAPI()

class IngestRequest(BaseModel):
    url: HttpUrl
    strict: bool = True
    model: str = "gpt-4"

@app.post("/ingest")
async def ingest_url(request: IngestRequest):
    try:
        doc = ingest(str(request.url), strict=request.strict, model=request.model)
        
        return {
            "markdown": doc.markdown,
            "tokens": doc.token_estimate,
            "injection_score": doc.injection_score,
            "hash": doc.content_hash,
            "risk_level": doc.metadata['risk_level']
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
```

### Deduplication Using Hashes

```python
from markdown_ingress import ingest

seen_hashes = set()
unique_docs = []

for url in urls:
    doc = ingest(url)
    
    if doc.content_hash not in seen_hashes:
        seen_hashes.add(doc.content_hash)
        unique_docs.append(doc)
    else:
        print(f"Duplicate content: {url}")

print(f"Unique: {len(unique_docs)} / Total: {len(urls)}")
```

---

## Security Features

### Injection Detection Patterns

MarkDownIngress detects common prompt injection patterns:

| Pattern | Weight | Example |
|---------|--------|---------|
| Instruction Override | 0.8 | "ignore previous instructions" |
| System Prompt Access | 0.6 | "reveal system prompt" |
| Mode Switching | 0.7 | "enable developer mode" |
| Secret Extraction | 0.9 | "reveal secret keys" |
| Model Manipulation | 0.5 | "you are ChatGPT" |
| Policy Override | 0.8 | "override policy settings" |

### Risk Levels

| Score | Level | Action |
|-------|-------|--------|
| 0.0 - 0.2 | **SAFE** | ✅ Content appears safe |
| 0.2 - 0.4 | **LOW** | ⚠️ Review recommended |
| 0.4 - 0.6 | **MEDIUM** | ⚠️ Manual review required |
| 0.6 - 0.8 | **HIGH** | 🚫 Use with caution |
| 0.8 - 1.0 | **CRITICAL** | 🚫 Blocking recommended |

---

## Architecture

```
markdown_ingress/
    core/
        fetcher.py       # HTTP client (httpx)
        extractor.py     # Content extraction (readability-lxml + selectolax)
        normalizer.py    # Unicode/whitespace normalization
        markdown.py      # HTML → Markdown conversion (markdownify)
        security.py      # Injection pattern detection
        scoring.py       # Risk level calculation
        hashing.py       # Deterministic SHA256 hashing
        tokens.py        # Token estimation (tiktoken)
    models.py            # Data models (SafeDocument, etc.)
    api.py               # Main ingest() function
    cli.py               # Command-line interface
```

---

## Roadmap

| Version | Status | Features |
|---------|--------|----------|
| **v0.1** | ✅ Released | Fast mode, injection detection, CLI, token estimation |
| **v0.2** | ✅ Released | Playwright render mode, SPA support |
| **v0.7** | ✅ **Current** | ✨ Auto mode, advanced security hooks, metadata/link extraction, API + CLI |
| **v0.8** | 📋 Planned | Policy/cache/plugin hardening, stronger offline test fixtures, docs cleanup |

---

## Requirements

- Python 3.11+
- Core dependencies:
  - `httpx` — Async HTTP client
  - `selectolax` — Fast HTML parser
  - `readability-lxml` — Content extraction
  - `markdownify` — HTML → Markdown conversion
  - `tiktoken` — Token counting
- Optional (for render mode):
  - `playwright` — Headless browser automation ✨ **NEW**
- Optional (for advanced security mode):
  - `nova-hunting` — Nova semantic / LLM-assisted prompt injection detection

See [pyproject.toml](pyproject.toml) for complete dependency list.

---

## Development

### Setup

```bash
git clone https://github.com/seifreed/MarkDownIngress.git
cd MarkDownIngress
python3 -m venv venv
source venv/bin/activate
pip install -e ".[dev]"
playwright install chromium
```

### Run Tests

```bash
pytest tests/ -v                    # Run all tests
pytest tests/ --cov=markdown_ingress  # With coverage
```

### Project Scope

- Python library + CLI + FastAPI server
- Fast, render and auto ingestion modes
- Batch, cache, policy, plugin and security-report workflows
- Test suite covering unit, integration and CLI/API paths

---

## Contributing

Contributions are welcome! Please:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Add tests for new functionality
4. Ensure all tests pass (`pytest tests/ -v`)
5. Submit a pull request

---

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

## FAQ

**Q: Why not just use Pandoc or html2text?**  
A: Those are converters. MarkDownIngress is an **ingestion security engine** with injection detection, deterministic hashing, and LLM-optimized output.

**Q: Does it work with JavaScript-heavy sites?**  
A: ✨ **Yes!** v0.2 includes Playwright render mode for full SPA support. Use `mode="render"` or `--render` flag.

**Q: How accurate is the injection detection?**  
A: Base installs use deterministic heuristics. If you install `.[security]`, Nova-based semantic and optional LLM-assisted detection are also available.

**Q: Can I use this in production?**  
A: `0.7.0` is still marked beta. Fast mode is the most predictable path; render mode is broader but heavier. Review security scores and policy decisions for critical workflows.

**Q: How is this different from Trafilatura/Newspaper3k?**  
A: Those focus on article extraction. We add **security analysis**, **deterministic hashing**, and **LLM-specific token optimization**.

---

<p align="center">
  <sub>Built for the LLM era. Secure by default. Deterministic by design.</sub>
</p>
